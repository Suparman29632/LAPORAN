package com.example.biodata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
